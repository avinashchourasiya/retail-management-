/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package stockmanagment1;

public class StockManagment1 {

    public static void main(String[] args) {
        Login l=new Login();
        l.setVisible(true);
    }
}
